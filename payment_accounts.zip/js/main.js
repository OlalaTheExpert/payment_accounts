$(function(){
    $('a[title]').tooltip();
    });